using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MouseRaycaster : MonoBehaviour
{
	public Text positionText;

	void Update()
	{
		if (Input.GetMouseButton(0))
		{
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray, out hit))
			{
				TileInfo tileInfo = hit.transform.GetComponent<TileInfo>();
				if (tileInfo != null)
				{
					Vector2 tilePosition = tileInfo.GetPosition();
					positionText.text = "Tile Position: " + tilePosition;
				}
			}
		}
	}
}

