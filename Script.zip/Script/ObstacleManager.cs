using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleManager : MonoBehaviour
{
	public ObstacleData obstacleData;
	public GameObject obstaclePrefab;

	void Start()
	{
		GenerateObstacles();
	}

	void GenerateObstacles()
	{
		for (int x = 0; x < 10; x++)
		{
			for (int y = 0; y < 10; y++)
			{
				if (obstacleData.obstacleGrid[x * 10 + y])
				{
					Vector3 position = new Vector3(x, 0.5f, y); // Adjust y position to place the sphere above the grid
					Instantiate(obstaclePrefab, position, Quaternion.identity);
				}
			}
		}
	}
}
