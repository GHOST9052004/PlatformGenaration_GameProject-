using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAI
{
	void MoveTowards(Vector3 targetPosition);
	bool IsMoving();
}
