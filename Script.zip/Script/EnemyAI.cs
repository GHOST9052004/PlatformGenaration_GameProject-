using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour, IAI
{
	public float moveSpeed = 2f;
	private Queue<Vector3> path = new Queue<Vector3>();
	private bool isMoving = false;
	private PlayerController playerController;
	public ObstacleData obstacleData;
	public Pathfinding pathfinding;

	void Start()
	{
		playerController = FindObjectOfType<PlayerController>();
	}

	void Update()
	{
		if (!isMoving && !playerController.IsMoving())
		{
			MoveToPlayer();
		}

		if (isMoving)
		{
			MoveAlongPath();
		}
	}

	private void MoveToPlayer()
	{
		Vector2Int start = new Vector2Int((int)transform.position.x, (int)transform.position.z);
		Vector2Int playerPosition = new Vector2Int((int)playerController.transform.position.x, (int)playerController.transform.position.z);
		List<Vector2Int> path = pathfinding.FindPath(start, playerPosition, obstacleData.obstacleGrid, 10, 10);

		if (path != null && path.Count > 1)
		{
			Vector2Int nextPosition = path[1]; // Move to the next tile in the path
			SetPath(new List<Vector2Int> { nextPosition });
		}
	}

	public void SetPath(List<Vector2Int> path)
	{
		this.path.Clear();
		foreach (Vector2Int point in path)
		{
			this.path.Enqueue(new Vector3(point.x, 0.5f, point.y));
		}
		isMoving = true;
	}

	private void MoveAlongPath()
	{
		if (path.Count > 0)
		{
			Vector3 targetPosition = path.Peek();
			if (Vector3.Distance(transform.position, targetPosition) > 0.1f)
			{
				transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
			}
			else
			{
				transform.position = targetPosition;
				path.Dequeue();
			}
		}
		else
		{
			isMoving = false;
		}
	}

	public void MoveTowards(Vector3 targetPosition)
	{
		SetPath(new List<Vector2Int> { new Vector2Int((int)targetPosition.x, (int)targetPosition.z) });
	}

	public bool IsMoving()
	{
		return isMoving;
	}
}

