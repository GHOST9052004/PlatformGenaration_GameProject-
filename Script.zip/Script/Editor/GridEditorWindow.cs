using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class GridEditorWindow : EditorWindow
{
	private ObstacleData obstacleData;

	[MenuItem("Window/Grid Editor")]
	public static void ShowWindow()
	{
		GetWindow<GridEditorWindow>("Grid Editor");
	}

	private void OnGUI()
	{
		GUILayout.Label("Grid Editor", EditorStyles.boldLabel);

		obstacleData = (ObstacleData)EditorGUILayout.ObjectField("Obstacle Data", obstacleData, typeof(ObstacleData), false);

		if (obstacleData == null)
			return;

		for (int x = 0; x < 10; x++)
		{
			EditorGUILayout.BeginHorizontal();
			for (int y = 0; y < 10; y++)
			{
				bool isObstacle = GUILayout.Toggle(obstacleData.obstacleGrid[x * 10 + y], "");
				obstacleData.obstacleGrid[x * 10 + y] = isObstacle;
			}
			EditorGUILayout.EndHorizontal();
		}

		if (GUI.changed)
		{
			EditorUtility.SetDirty(obstacleData);
		}
	}
}