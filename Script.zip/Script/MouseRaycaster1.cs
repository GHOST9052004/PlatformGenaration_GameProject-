using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MouseRaycaster1 : MonoBehaviour
{
	public Text positionText;
	public PlayerController playerController;
	public EnemyAI enemyAI;
	public ObstacleData obstacleData;
	public Pathfinding pathfinding;

	void Update()
	{
		if (Input.GetMouseButtonDown(0) && !playerController.IsMoving())
		{
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray, out hit))
			{
				TileInfo tileInfo = hit.transform.GetComponent<TileInfo>();
				if (tileInfo != null)
				{
					Vector2 tilePosition = tileInfo.GetPosition();
					positionText.text = "Tile Position: " + tilePosition;
					if (!IsObstacle((int)tilePosition.x, (int)tilePosition.y))
					{
						Vector2Int start = new Vector2Int((int)playerController.transform.position.x, (int)playerController.transform.position.z);
						Vector2Int goal = new Vector2Int((int)tilePosition.x, (int)tilePosition.y);
						List<Vector2Int> path = pathfinding.FindPath(start, goal, obstacleData.obstacleGrid, 10, 10);
						if (path != null)
						{
							playerController.SetPath(path);
						}
					}
				}
			}
		}
	}

	private bool IsObstacle(int x, int y)
	{
		return obstacleData.obstacleGrid[x * 10 + y];
	}
}

