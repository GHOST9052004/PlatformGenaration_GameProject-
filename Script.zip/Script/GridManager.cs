using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GridManager : MonoBehaviour
{
	public GameObject cubePrefab;
	public int gridWidth = 10;
	public int gridHeight = 10;

	void Start()
	{
		GenerateGrid();
	}

	void GenerateGrid()
	{
		for (int x = 0; x < gridWidth; x++)
		{
			for (int y = 0; y < gridHeight; y++)
			{
				Vector3 position = new Vector3(x, 0, y);
				GameObject cube = Instantiate(cubePrefab, position, Quaternion.identity);
				cube.GetComponent<TileInfo>().SetPosition(x, y);
			}
		}
	}
}
