using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pathfinding : MonoBehaviour
{
	private static readonly Vector2Int[] directions = new Vector2Int[]
	{
		new Vector2Int(0, 1), new Vector2Int(1, 0), new Vector2Int(0, -1), new Vector2Int(-1, 0)
	};

	public List<Vector2Int> FindPath(Vector2Int start, Vector2Int goal, bool[] obstacles, int width, int height)
	{
		Queue<Vector2Int> queue = new Queue<Vector2Int>();
		Dictionary<Vector2Int, Vector2Int> cameFrom = new Dictionary<Vector2Int, Vector2Int>();
		queue.Enqueue(start);
		cameFrom[start] = start;

		while (queue.Count > 0)
		{
			Vector2Int current = queue.Dequeue();
			if (current == goal)
			{
				return ReconstructPath(cameFrom, start, goal);
			}

			foreach (Vector2Int direction in directions)
			{
				Vector2Int neighbor = current + direction;
				if (IsValidPosition(neighbor, width, height) && !IsObstacle(neighbor, obstacles, width) && !cameFrom.ContainsKey(neighbor))
				{
					queue.Enqueue(neighbor);
					cameFrom[neighbor] = current;
				}
			}
		}
		return null; // No path found
	}

	private bool IsValidPosition(Vector2Int position, int width, int height)
	{
		return position.x >= 0 && position.x < width && position.y >= 0 && position.y < height;
	}

	private bool IsObstacle(Vector2Int position, bool[] obstacles, int width)
	{
		return obstacles[position.x * width + position.y];
	}

	private List<Vector2Int> ReconstructPath(Dictionary<Vector2Int, Vector2Int> cameFrom, Vector2Int start, Vector2Int goal)
	{
		List<Vector2Int> path = new List<Vector2Int>();
		Vector2Int current = goal;
		while (current != start)
		{
			path.Add(current);
			current = cameFrom[current];
		}
		path.Add(start);
		path.Reverse();
		return path;
	}
}


