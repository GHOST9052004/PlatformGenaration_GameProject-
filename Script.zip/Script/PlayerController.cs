using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerController : MonoBehaviour, IAI
{
	public float moveSpeed = 2f;
	private Queue<Vector3> path = new Queue<Vector3>();
	private bool isMoving = false;
	private Animator animator;

	void Start()
	{
		animator = GetComponent<Animator>();
		animator.SetBool("IsWalking", false); // Set the initial animation state
	}

	void Update()
	{
		if (isMoving)
		{
			MoveAlongPath();
		}
	}

	public void SetPath(List<Vector2Int> path)
	{
		this.path.Clear();
		foreach (Vector2Int point in path)
		{
			this.path.Enqueue(new Vector3(point.x, 0.5f, point.y));
		}
		isMoving = true;
		animator.SetBool("IsWalking", true); // Set walking animation
	}

	private void MoveAlongPath()
	{
		if (path.Count > 0)
		{
			Vector3 targetPosition = path.Peek();
			if (Vector3.Distance(transform.position, targetPosition) > 0.1f)
			{
				transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
			}
			else
			{
				transform.position = targetPosition;
				path.Dequeue();
			}
		}
		else
		{
			isMoving = false;
			animator.SetBool("IsWalking", false); // Set idle animation
		}
	}

	public void MoveTowards(Vector3 targetPosition)
	{
		SetPath(new List<Vector2Int> { new Vector2Int((int)targetPosition.x, (int)targetPosition.z) });
	}

	public bool IsMoving()
	{
		return isMoving;
	}
}
